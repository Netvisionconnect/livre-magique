'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { Checkbox } from '@/components/ui/checkbox'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Progress } from '@/components/ui/progress'
import { Download, FileText, Book, Printer, Share2 } from 'lucide-react'

export default function ExportPage() {
  const [exportFormat, setExportFormat] = useState('pdf-print')
  const [colorMode, setColorMode] = useState('rgb')
  const [quality, setQuality] = useState('standard')
  const [isExporting, setIsExporting] = useState(false)
  const [exportProgress, setExportProgress] = useState(0)
  const [exportComplete, setExportComplete] = useState(false)
  const [exportedFiles, setExportedFiles] = useState<string[]>([])

  const handleExport = async () => {
    setIsExporting(true)
    setExportProgress(0)
    setExportComplete(false)
    
    // Simuler la progression de l'exportation
    const interval = setInterval(() => {
      setExportProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval)
          return 100
        }
        return prev + 5
      })
    }, 200)
    
    // Simuler le temps d'exportation
    await new Promise(resolve => setTimeout(resolve, 4000))
    
    clearInterval(interval)
    setExportProgress(100)
    
    // Simuler les fichiers exportés
    const files = []
    
    if (exportFormat === 'pdf-print' || exportFormat === 'pdf-all') {
      files.push('Mon_Livre_Print.pdf')
    }
    
    if (exportFormat === 'pdf-ebook' || exportFormat === 'pdf-all') {
      files.push('Mon_Livre_eBook.pdf')
    }
    
    if (exportFormat === 'epub' || exportFormat === 'pdf-all') {
      files.push('Mon_Livre.epub')
    }
    
    setExportedFiles(files)
    setIsExporting(false)
    setExportComplete(true)
  }

  return (
    <main className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-2">Export multi-format</h1>
        <p className="text-gray-600 mb-8">
          Générez des fichiers PDF prêts pour l'impression et la distribution.
        </p>

        {exportComplete ? (
          <div className="space-y-6">
            <Card className="p-6 border-green-200 bg-green-50">
              <div className="flex items-center space-x-4">
                <div className="bg-green-100 p-2 rounded-full">
                  <Download className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-medium text-green-800">Exportation réussie!</h3>
                  <p className="text-green-700 mt-1">
                    Vos fichiers ont été générés avec succès. Vous pouvez maintenant les télécharger.
                  </p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <h2 className="text-xl font-semibold mb-4">Fichiers exportés</h2>
              <div className="space-y-4">
                {exportedFiles.map((file, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                    <div className="flex items-center space-x-3">
                      <FileText className="h-8 w-8 text-teal-600" />
                      <div>
                        <p className="font-medium">{file}</p>
                        <p className="text-sm text-gray-500">
                          {file.endsWith('.pdf') 
                            ? file.includes('Print') 
                              ? 'PDF optimisé pour l\'impression' 
                              : 'PDF optimisé pour la lecture numérique'
                            : 'Format eBook compatible avec la plupart des liseuses'}
                        </p>
                      </div>
                    </div>
                    <Button size="sm" className="bg-teal-600 hover:bg-teal-700">
                      <Download className="h-4 w-4 mr-2" />
                      Télécharger
                    </Button>
                  </div>
                ))}
              </div>

              <div className="mt-6 pt-6 border-t flex flex-col sm:flex-row justify-between gap-4">
                <Button variant="outline" onClick={() => setExportComplete(false)}>
                  Modifier les options d'export
                </Button>
                <div className="flex gap-2">
                  <Button variant="outline">
                    <Share2 className="h-4 w-4 mr-2" />
                    Partager
                  </Button>
                  <Button className="bg-teal-600 hover:bg-teal-700">
                    Exporter un autre livre
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        ) : (
          <div className="space-y-8">
            {isExporting ? (
              <Card className="p-6">
                <h2 className="text-xl font-semibold mb-4">Exportation en cours</h2>
                <div className="space-y-4">
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium">Génération des fichiers...</span>
                    <span className="text-sm font-medium">{exportProgress}%</span>
                  </div>
                  <Progress value={exportProgress} className="h-2" />
                  <p className="text-sm text-gray-500 italic">
                    Veuillez patienter pendant que nous préparons vos fichiers...
                  </p>
                </div>
              </Card>
            ) : (
              <>
                <Card className="p-6">
                  <h2 className="text-xl font-semibold mb-4">Format d'exportation</h2>
                  <RadioGroup 
                    value={exportFormat} 
                    onValueChange={setExportFormat}
                    className="space-y-4"
                  >
                    <div className="flex items-start space-x-2">
                      <RadioGroupItem value="pdf-print" id="format-pdf-print" className="mt-1" />
                      <Label 
                        htmlFor="format-pdf-print" 
                        className="flex flex-col cursor-pointer"
                      >
                        <span className="font-medium">PDF pour impression</span>
                        <span className="text-sm text-gray-500">
                          Optimisé pour l'impression à la demande (KDP, IngramSpark)
                        </span>
                      </Label>
                    </div>
                    
                    <div className="flex items-start space-x-2">
                      <RadioGroupItem value="pdf-ebook" id="format-pdf-ebook" className="mt-1" />
                      <Label 
                        htmlFor="format-pdf-ebook" 
                        className="flex flex-col cursor-pointer"
                      >
                        <span className="font-medium">PDF pour eBook</span>
                        <span className="text-sm text-gray-500">
                          Optimisé pour la lecture sur écran
                        </span>
                      </Label>
                    </div>
                    
                    <div className="flex items-start space-x-2">
                      <RadioGroupItem value="epub" id="format-epub" className="mt-1" />
                      <Label 
                        htmlFor="format-epub" 
                        className="flex flex-col cursor-pointer"
                      >
                        <span className="font-medium">EPUB</span>
                        <span className="text-sm text-gray-500">
                          Format eBook compatible avec la plupart des liseuses
                        </span>
                      </Label>
                    </div>
                    
                    <div className="flex items-start space-x-2">
                      <RadioGroupItem value="pdf-all" id="format-all" className="mt-1" />
                      <Label 
                        htmlFor="format-all" 
                        className="flex flex-col cursor-pointer"
                      >
                        <span className="font-medium">Tous les formats</span>
                        <span className="text-sm text-gray-500">
                          Exporter en PDF pour impression, PDF pour eBook et EPUB
                        </span>
                      </Label>
                    </div>
                  </RadioGroup>
                </Card>

                <Tabs defaultValue="basic" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="basic">Options de base</TabsTrigger>
                    <TabsTrigger value="advanced">Options avancées</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="basic" className="space-y-6 pt-6">
                    <Card className="p-6">
                      <h2 className="text-xl font-semibold mb-4">Options de base</h2>
                      
                      <div className="space-y-6">
                        <div>
                          <Label htmlFor="color-mode" className="block mb-2">Mode de couleur</Label>
                          <RadioGroup 
                            value={colorMode} 
                            onValueChange={setColorMode}
                            className="flex flex-col space-y-2"
                            id="color-mode"
                          >
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="rgb" id="color-rgb" />
                              <Label htmlFor="color-rgb">RGB (écran, web)</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="cmyk" id="color-cmyk" />
                              <Label htmlFor="color-cmyk">CMYK (impression professionnelle)</Label>
                            </div>
                          </RadioGroup>
                        </div>
                        
                        <div>
                          <Label htmlFor="quality" className="block mb-2">Qualité</Label>
                          <RadioGroup 
                            value={quality} 
                            onValueChange={setQuality}
                            className="flex flex-col space-y-2"
                            id="quality"
                          >
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="draft" id="quality-draft" />
                              <Label htmlFor="quality-draft">Brouillon (72 dpi)</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="standard" id="quality-standard" />
                              <Label htmlFor="quality-standard">Standard (150 dpi)</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="high" id="quality-high" />
                              <Label htmlFor="quality-high">Haute qualité (300 dpi)</Label>
                            </div>
                          </RadioGroup>
                        </div>
                        
                        <div className="space-y-2">
                          <Label className="block mb-2">Inclure</Label>
                          
                          <div className="flex items-start space-x-2">
                            <Checkbox id="include-cover" defaultChecked />
                            <div className="grid gap-1.5 leading-none">
                              <Label htmlFor="include-cover" className="cursor-pointer">
                                Couverture
                              </Label>
                              <p className="text-sm text-gray-500">
                                Inclure la couverture dans le document exporté
                              </p>
                            </div>
                          </div>
                          
                          <div className="flex items-start space-x-2">
                            <Checkbox id="include-toc" defaultChecked />
                            <div className="grid gap-1.5 leading-none">
                              <Label htmlFor="include-toc" className="cursor-pointer">
                                Table des matières
                              </Label>
                              <p className="text-sm text-gray-500">
                                Générer automatiquement une table des matières
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Card>
                  </TabsContent>
                  
                  <TabsContent value="advanced" className="space-y-6 pt-6">
                    <Card className="p-6">
                      <h2 className="text-xl font-semibold mb-4">Options avancées</h2>
                      
                      <div className="space-y-6">
                        <div className="space-y-2">
                          <Label className="block mb-2">Repères d'impression</Label>
                          
                          <div className="flex items-start space-x-2">
                            <Checkbox id="bleed-marks" />
                            <div className="grid gap-1.5 leading-none">
                              <Label htmlFor="bleed-marks" className="cursor-pointer">
                                Fonds perdus
                              </Label>
                              <p className="text-sm text-gray-500">
                                Ajouter des fonds perdus (3mm)
                              </p>
                            </div>
                          </div>
                          
                          <div className="flex items-start space-x-2">
                            <Checkbox id="crop-marks" defaultChecked />
                            <div className="grid gap-1.5 leading-none">
                              <Label htmlFor="crop-marks" className="cursor-pointer">
                                Traits de coupe
                              </Label>
                              <p className="text-sm text-gray-500">
                                Ajouter des traits de coupe pour l'impression
                              </p>
                            </div>
                          </div>
                        </div>
                        
                        <div>
                          <Label htmlFor="metadata-title" className="block mb-2">Métadonnées du document</Label>
                          <div className="space-y-4">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div>
                                <Label htmlFor="metadata-title" className="text-sm">
                                  Titre
                                </Label>
                                <Input id="metadata-title" defaultValue="Mon Livre" />
                              </div>
                              <div>
                                <Label htmlFor="metadata-author" className="text-sm">
                                  Auteur
                                </Label>
                                <Input id="metadata-author" defaultValue="Votre Nom" />
                              </div>
                            </div>
                            <div>
                              <Label htmlFor="metadata-subject" className="text-sm">
                                Sujet
                              </Label>
                              <Input id="metadata-subject" />
                            </div>
                            <div>
                              <Label htmlFor="metadata-keywords" className="text-sm">
                                Mots-clés (séparés par des virgules)
                              </Label>
                              <Input id="metadata-keywords" />
                            </div>
                          </div>
                        </div>
                      </div>
                    </Card>
                  </TabsContent>
                </Tabs>

                <div className="flex justify-end space-x-4 pt-4">
                  <Button variant="outline">
                    Retour à la validation
                  </Button>
                  <Button 
                    className="bg-teal-600 hover:bg-teal-700"
                    onClick={handleExport}
                  >
                    Exporter
                  </Button>
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </main>
  )
}
