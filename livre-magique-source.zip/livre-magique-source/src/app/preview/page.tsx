'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ChevronLeft, ChevronRight, ZoomIn, ZoomOut, Printer, Download } from 'lucide-react'
import { Slider } from '@/components/ui/slider'

export default function PreviewPage() {
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(24)
  const [zoomLevel, setZoomLevel] = useState([100])
  const [viewMode, setViewMode] = useState('single')

  const handlePreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1)
    }
  }

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1)
    }
  }

  const handleZoomIn = () => {
    if (zoomLevel[0] < 200) {
      setZoomLevel([zoomLevel[0] + 25])
    }
  }

  const handleZoomOut = () => {
    if (zoomLevel[0] > 50) {
      setZoomLevel([zoomLevel[0] - 25])
    }
  }

  return (
    <main className="container mx-auto px-4 py-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold mb-2">Prévisualisation en temps réel</h1>
        <p className="text-gray-600 mb-6">
          Visualisez votre livre comme il apparaîtra une fois imprimé.
        </p>

        <div className="flex flex-col space-y-4">
          {/* Contrôles de prévisualisation */}
          <div className="flex justify-between items-center bg-gray-50 p-3 rounded-lg">
            <div className="flex items-center space-x-2">
              <Button 
                variant="outline" 
                size="icon" 
                onClick={handleZoomOut}
                disabled={zoomLevel[0] <= 50}
              >
                <ZoomOut className="h-4 w-4" />
              </Button>
              <div className="w-24">
                <Slider
                  value={zoomLevel}
                  min={50}
                  max={200}
                  step={25}
                  onValueChange={setZoomLevel}
                />
              </div>
              <Button 
                variant="outline" 
                size="icon" 
                onClick={handleZoomIn}
                disabled={zoomLevel[0] >= 200}
              >
                <ZoomIn className="h-4 w-4" />
              </Button>
              <span className="text-sm text-gray-600">{zoomLevel[0]}%</span>
            </div>

            <div className="flex items-center">
              <Tabs value={viewMode} onValueChange={setViewMode} className="mr-4">
                <TabsList className="h-8">
                  <TabsTrigger value="single" className="text-xs px-2 py-1">
                    Page simple
                  </TabsTrigger>
                  <TabsTrigger value="double" className="text-xs px-2 py-1">
                    Double page
                  </TabsTrigger>
                </TabsList>
              </Tabs>

              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm">
                  <Printer className="h-4 w-4 mr-1" />
                  Imprimer
                </Button>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-1" />
                  Exporter PDF
                </Button>
              </div>
            </div>
          </div>

          {/* Zone de prévisualisation */}
          <div className="flex flex-col items-center bg-gray-100 p-8 rounded-lg min-h-[600px]">
            <div 
              className="bg-white shadow-lg mx-auto mb-6 overflow-hidden"
              style={{
                width: viewMode === 'single' ? `${6 * zoomLevel[0] / 100}in` : `${12 * zoomLevel[0] / 100}in`,
                height: `${9 * zoomLevel[0] / 100}in`,
                maxWidth: '100%',
                maxHeight: '70vh'
              }}
            >
              {viewMode === 'single' ? (
                <div className="w-full h-full flex items-center justify-center border border-gray-200">
                  <div className="text-center p-8">
                    <h2 className="text-xl font-bold mb-4">Chapitre {Math.ceil(currentPage / 2)}</h2>
                    <p className="mb-3">
                      Ceci est un exemple de texte qui apparaîtrait dans votre livre. Le formatage sera appliqué
                      selon les paramètres que vous avez choisis.
                    </p>
                    <p className="mb-3">
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt
                      ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                      ullamco laboris nisi ut aliquip ex ea commodo consequat.
                    </p>
                    <p>
                      Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat
                      nulla pariatur. Excepteur sint occaecat cupidatat non proident.
                    </p>
                    <div className="absolute bottom-4 right-4 text-gray-400">
                      Page {currentPage}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="w-full h-full flex">
                  <div className="w-1/2 border-r border-gray-300 p-4 flex items-center justify-center">
                    <div className="text-center p-4">
                      <h2 className="text-lg font-bold mb-3">Chapitre {Math.ceil(currentPage / 2)}</h2>
                      <p className="text-sm mb-2">
                        Ceci est un exemple de texte qui apparaîtrait dans votre livre. Le formatage sera appliqué
                        selon les paramètres que vous avez choisis.
                      </p>
                      <div className="absolute bottom-2 right-[50%] translate-x-[-12px] text-gray-400 text-xs">
                        Page {currentPage}
                      </div>
                    </div>
                  </div>
                  <div className="w-1/2 p-4 flex items-center justify-center">
                    <div className="text-center p-4">
                      <p className="text-sm mb-2">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt
                        ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.
                      </p>
                      <p className="text-sm">
                        Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat
                        nulla pariatur. Excepteur sint occaecat cupidatat non proident.
                      </p>
                      <div className="absolute bottom-2 right-4 text-gray-400 text-xs">
                        Page {currentPage + 1}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Navigation des pages */}
            <div className="flex items-center space-x-4">
              <Button 
                variant="outline" 
                size="icon"
                onClick={handlePreviousPage}
                disabled={currentPage <= 1}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              
              <span className="text-sm">
                Page {currentPage}{viewMode === 'double' && currentPage < totalPages ? `-${currentPage + 1}` : ''} sur {totalPages}
              </span>
              
              <Button 
                variant="outline" 
                size="icon"
                onClick={handleNextPage}
                disabled={viewMode === 'single' ? currentPage >= totalPages : currentPage >= totalPages - 1}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-between pt-4">
            <Button variant="outline">
              Retour au formatage
            </Button>
            <Button className="bg-teal-600 hover:bg-teal-700">
              Personnalisation avancée
            </Button>
          </div>
        </div>
      </div>
    </main>
  )
}
