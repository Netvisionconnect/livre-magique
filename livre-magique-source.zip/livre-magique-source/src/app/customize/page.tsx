'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Slider } from '@/components/ui/slider'
import { Switch } from '@/components/ui/switch'
import { ColorPicker } from '@/components/color-picker'
import { Paintbrush, Type, Layout, Save } from 'lucide-react'

export default function CustomizePage() {
  const [fontFamily, setFontFamily] = useState('georgia')
  const [fontSize, setFontSize] = useState([12])
  const [lineHeight, setLineHeight] = useState([1.5])
  const [textColor, setTextColor] = useState('#000000')
  const [headingColor, setHeadingColor] = useState('#333333')
  const [isSaving, setIsSaving] = useState(false)
  const [isCustomized, setIsCustomized] = useState(false)

  const handleSaveCustomization = async () => {
    setIsSaving(true)
    
    // Simuler le traitement
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    setIsSaving(false)
    setIsCustomized(true)
  }

  return (
    <main className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-2">Personnalisation avancée</h1>
        <p className="text-gray-600 mb-8">
          Ajustez les marges, le formatage, et les styles selon vos préférences pour créer un livre unique.
        </p>

        {isCustomized ? (
          <div className="space-y-6">
            <Card className="p-6 border-green-200 bg-green-50">
              <div className="flex items-center space-x-4">
                <div className="bg-green-100 p-2 rounded-full">
                  <Save className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-medium text-green-800">Personnalisation enregistrée avec succès!</h3>
                  <p className="text-green-700 mt-1">
                    Vos préférences de style ont été appliquées à votre livre. Vous pouvez maintenant passer à la validation des normes ou exporter votre livre.
                  </p>
                </div>
              </div>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
              <Card className="p-6 hover:shadow-md transition-shadow">
                <div className="flex flex-col h-full">
                  <div className="mb-4">
                    <Layout className="h-10 w-10 text-teal-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Validation des normes</h3>
                  <p className="text-gray-600 mb-4 flex-grow">
                    Vérifiez que votre livre est conforme aux exigences des plateformes d'impression.
                  </p>
                  <Button className="w-full bg-teal-600 hover:bg-teal-700">
                    Valider le livre
                  </Button>
                </div>
              </Card>

              <Card className="p-6 hover:shadow-md transition-shadow">
                <div className="flex flex-col h-full">
                  <div className="mb-4">
                    <Save className="h-10 w-10 text-teal-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Exporter</h3>
                  <p className="text-gray-600 mb-4 flex-grow">
                    Générez des fichiers PDF prêts pour l'impression et la distribution.
                  </p>
                  <Button className="w-full bg-teal-600 hover:bg-teal-700">
                    Exporter le livre
                  </Button>
                </div>
              </Card>
            </div>
          </div>
        ) : (
          <div className="space-y-8">
            <Tabs defaultValue="typography" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="typography">Typographie</TabsTrigger>
                <TabsTrigger value="colors">Couleurs</TabsTrigger>
                <TabsTrigger value="layout">Mise en page</TabsTrigger>
              </TabsList>
              
              <TabsContent value="typography" className="space-y-6 pt-6">
                <div>
                  <h2 className="text-xl font-semibold mb-4">Police de caractères</h2>
                  <Select value={fontFamily} onValueChange={setFontFamily}>
                    <SelectTrigger className="w-full md:w-1/2">
                      <SelectValue placeholder="Sélectionnez une police" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="georgia">Georgia</SelectItem>
                      <SelectItem value="times">Times New Roman</SelectItem>
                      <SelectItem value="garamond">Garamond</SelectItem>
                      <SelectItem value="baskerville">Baskerville</SelectItem>
                      <SelectItem value="palatino">Palatino</SelectItem>
                      <SelectItem value="bookman">Bookman</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-gray-500 mt-2">
                    Choisissez une police adaptée au type de livre que vous créez.
                  </p>
                </div>

                <div>
                  <div className="flex justify-between mb-2">
                    <Label htmlFor="font-size-slider">Taille de police: {fontSize[0]}pt</Label>
                  </div>
                  <Slider
                    id="font-size-slider"
                    min={8}
                    max={16}
                    step={0.5}
                    value={fontSize}
                    onValueChange={setFontSize}
                    className="w-full md:w-2/3"
                  />
                  <p className="text-sm text-gray-500 mt-2">
                    La taille standard pour les livres est entre 10pt et 12pt.
                  </p>
                </div>

                <div>
                  <div className="flex justify-between mb-2">
                    <Label htmlFor="line-height-slider">Interligne: {lineHeight[0]}</Label>
                  </div>
                  <Slider
                    id="line-height-slider"
                    min={1}
                    max={2}
                    step={0.1}
                    value={lineHeight}
                    onValueChange={setLineHeight}
                    className="w-full md:w-2/3"
                  />
                  <p className="text-sm text-gray-500 mt-2">
                    Un interligne de 1.5 est généralement recommandé pour une bonne lisibilité.
                  </p>
                </div>

                <div className="space-y-4">
                  <h2 className="text-xl font-semibold">Styles de texte</h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="heading-style">Style des titres</Label>
                      <Select defaultValue="centered">
                        <SelectTrigger id="heading-style">
                          <SelectValue placeholder="Style des titres" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="centered">Centré</SelectItem>
                          <SelectItem value="left">Aligné à gauche</SelectItem>
                          <SelectItem value="numbered">Numéroté</SelectItem>
                          <SelectItem value="decorative">Décoratif</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label htmlFor="paragraph-style">Style des paragraphes</Label>
                      <Select defaultValue="indent">
                        <SelectTrigger id="paragraph-style">
                          <SelectValue placeholder="Style des paragraphes" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="indent">Indentation</SelectItem>
                          <SelectItem value="block">Bloc</SelectItem>
                          <SelectItem value="justified">Justifié</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="colors" className="space-y-6 pt-6">
                <div>
                  <h2 className="text-xl font-semibold mb-4">Couleurs du texte</h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label className="block mb-2">Couleur du texte principal</Label>
                      <div className="flex items-center space-x-4">
                        <div 
                          className="w-10 h-10 rounded border"
                          style={{ backgroundColor: textColor }}
                        />
                        <Input 
                          value={textColor} 
                          onChange={(e) => setTextColor(e.target.value)}
                          className="w-32"
                        />
                      </div>
                    </div>
                    
                    <div>
                      <Label className="block mb-2">Couleur des titres</Label>
                      <div className="flex items-center space-x-4">
                        <div 
                          className="w-10 h-10 rounded border"
                          style={{ backgroundColor: headingColor }}
                        />
                        <Input 
                          value={headingColor} 
                          onChange={(e) => setHeadingColor(e.target.value)}
                          className="w-32"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h2 className="text-xl font-semibold mb-4">Éléments décoratifs</h2>
                  
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="chapter-decoration" className="cursor-pointer">
                        Ornements de chapitre
                      </Label>
                      <Switch id="chapter-decoration" />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="drop-caps" className="cursor-pointer">
                        Lettrines en début de chapitre
                      </Label>
                      <Switch id="drop-caps" />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="section-dividers" className="cursor-pointer">
                        Séparateurs de section
                      </Label>
                      <Switch id="section-dividers" />
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="layout" className="space-y-6 pt-6">
                <div>
                  <h2 className="text-xl font-semibold mb-4">En-têtes et pieds de page</h2>
                  
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="header-title" className="cursor-pointer">
                        Titre du livre dans l'en-tête
                      </Label>
                      <Switch id="header-title" defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="header-author" className="cursor-pointer">
                        Nom de l'auteur dans l'en-tête
                      </Label>
                      <Switch id="header-author" />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="footer-page-number" className="cursor-pointer">
                        Numéro de page dans le pied de page
                      </Label>
                      <Switch id="footer-page-number" defaultChecked />
                    </div>
                  </div>
                </div>

                <div>
                  <h2 className="text-xl font-semibold mb-4">Pages spéciales</h2>
                  
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="title-page" className="cursor-pointer">
                        Page de titre
                      </Label>
                      <Switch id="title-page" defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="copyright-page" className="cursor-pointer">
                        Page de copyright
                      </Label>
                      <Switch id="copyright-page" defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="dedication-page" className="cursor-pointer">
                        Page de dédicace
                      </Label>
                      <Switch id="dedication-page" />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="toc-page" className="cursor-pointer">
                        Table des matières
                      </Label>
                      <Switch id="toc-page" defaultChecked />
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>

            <div className="flex justify-end space-x-4 pt-4 border-t">
              <Button variant="outline">
                Retour à la prévisualisation
              </Button>
              <Button 
                className="bg-teal-600 hover:bg-teal-700"
                onClick={handleSaveCustomization}
                disabled={isSaving}
              >
                {isSaving ? 'Enregistrement...' : 'Enregistrer les personnalisations'}
              </Button>
            </div>
          </div>
        )}
      </div>
    </main>
  )
}
