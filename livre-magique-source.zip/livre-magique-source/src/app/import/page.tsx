'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Upload, FileText, File, X } from 'lucide-react'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'

export default function ImportPage() {
  const [file, setFile] = useState<File | null>(null)
  const [isDragging, setIsDragging] = useState(false)
  const [isUploading, setIsUploading] = useState(false)
  const [uploadSuccess, setUploadSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0] || null
    validateAndSetFile(selectedFile)
  }

  const validateAndSetFile = (selectedFile: File | null) => {
    setError(null)
    
    if (!selectedFile) {
      return
    }

    // Vérifier le type de fichier
    const validTypes = ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/msword', 'text/plain', 'application/pdf']
    if (!validTypes.includes(selectedFile.type)) {
      setError('Format de fichier non supporté. Veuillez importer un document Word (.docx, .doc), un fichier texte (.txt) ou un PDF.')
      return
    }

    // Vérifier la taille du fichier (max 10MB)
    if (selectedFile.size > 10 * 1024 * 1024) {
      setError('Le fichier est trop volumineux. La taille maximale est de 10MB.')
      return
    }

    setFile(selectedFile)
  }

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setIsDragging(false)
    
    const droppedFile = e.dataTransfer.files?.[0] || null
    validateAndSetFile(droppedFile)
  }

  const handleRemoveFile = () => {
    setFile(null)
    setUploadSuccess(false)
  }

  const handleUpload = async () => {
    if (!file) return

    setIsUploading(true)
    setError(null)

    try {
      // Simuler un téléchargement
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      // Dans une implémentation réelle, nous enverrions le fichier au serveur ici
      // const formData = new FormData()
      // formData.append('manuscript', file)
      // const response = await fetch('/api/import', {
      //   method: 'POST',
      //   body: formData
      // })
      
      setUploadSuccess(true)
    } catch (err) {
      setError('Une erreur est survenue lors du téléchargement. Veuillez réessayer.')
    } finally {
      setIsUploading(false)
    }
  }

  const getFileIcon = () => {
    if (!file) return null
    
    if (file.type.includes('word')) {
      return <FileText className="h-12 w-12 text-blue-500" />
    } else if (file.type.includes('pdf')) {
      return <File className="h-12 w-12 text-red-500" />
    } else {
      return <File className="h-12 w-12 text-gray-500" />
    }
  }

  return (
    <main className="container mx-auto px-4 py-12">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold mb-2">Import de manuscrit</h1>
        <p className="text-gray-600 mb-8">
          Importez votre document Word, texte ou PDF pour commencer à créer votre livre.
        </p>

        {uploadSuccess ? (
          <div className="space-y-6">
            <Alert className="bg-green-50 border-green-200">
              <AlertTitle className="text-green-800 font-semibold">Importation réussie!</AlertTitle>
              <AlertDescription className="text-green-700">
                Votre manuscrit a été importé avec succès. Vous pouvez maintenant passer à l'étape de formatage.
              </AlertDescription>
            </Alert>
            
            <Card className="p-6 border-green-200 bg-green-50">
              <div className="flex items-center space-x-4">
                {getFileIcon()}
                <div className="flex-1">
                  <h3 className="font-medium">{file?.name}</h3>
                  <p className="text-sm text-gray-500">
                    {(file?.size / 1024 / 1024).toFixed(2)} MB • Importé avec succès
                  </p>
                </div>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={handleRemoveFile}
                  className="text-gray-500 hover:text-red-500"
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>
            </Card>

            <div className="flex justify-between mt-8">
              <Button variant="outline">Importer un autre manuscrit</Button>
              <Button className="bg-teal-600 hover:bg-teal-700">
                Passer au formatage
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <Card className="border-2 border-dashed p-0 overflow-hidden">
              <div
                className={`p-8 text-center ${isDragging ? 'bg-blue-50' : ''}`}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
              >
                {file ? (
                  <div className="flex flex-col items-center">
                    {getFileIcon()}
                    <h3 className="font-medium mt-4">{file.name}</h3>
                    <p className="text-sm text-gray-500 mb-4">
                      {(file.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                    <div className="flex space-x-3">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={handleRemoveFile}
                        className="text-red-500 border-red-200 hover:bg-red-50"
                      >
                        Supprimer
                      </Button>
                      <Button 
                        size="sm" 
                        onClick={handleUpload}
                        disabled={isUploading}
                        className="bg-teal-600 hover:bg-teal-700"
                      >
                        {isUploading ? 'Importation...' : 'Importer'}
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div>
                    <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium mb-2">
                      Glissez-déposez votre manuscrit ici
                    </h3>
                    <p className="text-gray-500 mb-4">
                      ou sélectionnez un fichier depuis votre ordinateur
                    </p>
                    <Label htmlFor="file-upload" className="cursor-pointer">
                      <div className="bg-teal-600 hover:bg-teal-700 text-white py-2 px-4 rounded-md inline-flex items-center">
                        <Upload className="h-4 w-4 mr-2" />
                        Parcourir les fichiers
                      </div>
                      <Input
                        id="file-upload"
                        type="file"
                        className="hidden"
                        accept=".docx,.doc,.txt,.pdf"
                        onChange={handleFileChange}
                      />
                    </Label>
                  </div>
                )}
              </div>
            </Card>

            {error && (
              <Alert variant="destructive">
                <AlertTitle>Erreur</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="font-medium mb-2">Formats pris en charge</h3>
              <ul className="list-disc list-inside text-gray-600 text-sm space-y-1">
                <li>Documents Microsoft Word (.docx, .doc)</li>
                <li>Fichiers texte (.txt)</li>
                <li>Documents PDF (.pdf)</li>
              </ul>
              <p className="text-sm text-gray-500 mt-2">
                Taille maximale de fichier: 10MB
              </p>
            </div>
          </div>
        )}
      </div>
    </main>
  )
}
