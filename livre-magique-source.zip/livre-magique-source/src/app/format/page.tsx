'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { FileText, BookOpen, Check } from 'lucide-react'

export default function FormatPage() {
  const [bookFormat, setBookFormat] = useState('6x9')
  const [paperType, setPaperType] = useState('white')
  const [bindingType, setBindingType] = useState('paperback')
  const [marginSize, setMarginSize] = useState([20]) // en mm
  const [autoFormat, setAutoFormat] = useState(true)
  const [platform, setPlatform] = useState('kdp')
  const [isProcessing, setIsProcessing] = useState(false)
  const [isFormatted, setIsFormatted] = useState(false)

  const handleFormatBook = async () => {
    setIsProcessing(true)
    
    // Simuler le traitement
    await new Promise(resolve => setTimeout(resolve, 3000))
    
    setIsProcessing(false)
    setIsFormatted(true)
  }

  const bookSizes = [
    { id: '5x8', name: '5 × 8 pouces', description: 'Format roman standard' },
    { id: '6x9', name: '6 × 9 pouces', description: 'Format le plus populaire' },
    { id: '7x10', name: '7 × 10 pouces', description: 'Pour livres illustrés' },
    { id: '8.5x11', name: '8,5 × 11 pouces', description: 'Format lettre US' },
  ]

  return (
    <main className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-2">Formatage automatique</h1>
        <p className="text-gray-600 mb-8">
          Configurez les paramètres de formatage pour votre livre et générez un document prêt pour l'impression.
        </p>

        {isFormatted ? (
          <div className="space-y-6">
            <Card className="p-6 border-green-200 bg-green-50">
              <div className="flex items-start space-x-4">
                <div className="bg-green-100 p-2 rounded-full">
                  <Check className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-medium text-green-800">Formatage terminé avec succès!</h3>
                  <p className="text-green-700 mt-1">
                    Votre manuscrit a été formaté selon les normes {platform === 'kdp' ? 'Amazon KDP' : 'IngramSpark'}.
                    Vous pouvez maintenant prévisualiser le résultat ou passer à la personnalisation avancée.
                  </p>
                </div>
              </div>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
              <Card className="p-6 hover:shadow-md transition-shadow">
                <div className="flex flex-col h-full">
                  <div className="mb-4">
                    <BookOpen className="h-10 w-10 text-teal-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Prévisualiser</h3>
                  <p className="text-gray-600 mb-4 flex-grow">
                    Visualisez votre livre comme il apparaîtra une fois imprimé.
                  </p>
                  <Button className="w-full bg-teal-600 hover:bg-teal-700">
                    Prévisualiser le livre
                  </Button>
                </div>
              </Card>

              <Card className="p-6 hover:shadow-md transition-shadow">
                <div className="flex flex-col h-full">
                  <div className="mb-4">
                    <FileText className="h-10 w-10 text-teal-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Personnaliser</h3>
                  <p className="text-gray-600 mb-4 flex-grow">
                    Ajustez les styles, les en-têtes, les pieds de page et plus encore.
                  </p>
                  <Button className="w-full bg-teal-600 hover:bg-teal-700">
                    Personnalisation avancée
                  </Button>
                </div>
              </Card>
            </div>
          </div>
        ) : (
          <div className="space-y-8">
            <Tabs defaultValue="basic" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="basic">Paramètres de base</TabsTrigger>
                <TabsTrigger value="advanced">Paramètres avancés</TabsTrigger>
              </TabsList>
              
              <TabsContent value="basic" className="space-y-6 pt-6">
                <div>
                  <h2 className="text-xl font-semibold mb-4">Format du livre</h2>
                  <RadioGroup 
                    value={bookFormat} 
                    onValueChange={setBookFormat}
                    className="grid grid-cols-1 md:grid-cols-2 gap-4"
                  >
                    {bookSizes.map(size => (
                      <div key={size.id} className="flex items-start space-x-2">
                        <RadioGroupItem value={size.id} id={`size-${size.id}`} className="mt-1" />
                        <Label 
                          htmlFor={`size-${size.id}`} 
                          className="flex flex-col cursor-pointer"
                        >
                          <span className="font-medium">{size.name}</span>
                          <span className="text-sm text-gray-500">{size.description}</span>
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>
                </div>

                <div>
                  <h2 className="text-xl font-semibold mb-4">Type de papier</h2>
                  <RadioGroup 
                    value={paperType} 
                    onValueChange={setPaperType}
                    className="grid grid-cols-1 md:grid-cols-3 gap-4"
                  >
                    <div className="flex items-start space-x-2">
                      <RadioGroupItem value="white" id="paper-white" className="mt-1" />
                      <Label 
                        htmlFor="paper-white" 
                        className="flex flex-col cursor-pointer"
                      >
                        <span className="font-medium">Blanc</span>
                        <span className="text-sm text-gray-500">Papier standard</span>
                      </Label>
                    </div>
                    <div className="flex items-start space-x-2">
                      <RadioGroupItem value="cream" id="paper-cream" className="mt-1" />
                      <Label 
                        htmlFor="paper-cream" 
                        className="flex flex-col cursor-pointer"
                      >
                        <span className="font-medium">Crème</span>
                        <span className="text-sm text-gray-500">Idéal pour romans</span>
                      </Label>
                    </div>
                    <div className="flex items-start space-x-2">
                      <RadioGroupItem value="premium" id="paper-premium" className="mt-1" />
                      <Label 
                        htmlFor="paper-premium" 
                        className="flex flex-col cursor-pointer"
                      >
                        <span className="font-medium">Premium</span>
                        <span className="text-sm text-gray-500">Haute qualité</span>
                      </Label>
                    </div>
                  </RadioGroup>
                </div>

                <div>
                  <h2 className="text-xl font-semibold mb-4">Type de reliure</h2>
                  <RadioGroup 
                    value={bindingType} 
                    onValueChange={setBindingType}
                    className="grid grid-cols-1 md:grid-cols-2 gap-4"
                  >
                    <div className="flex items-start space-x-2">
                      <RadioGroupItem value="paperback" id="binding-paperback" className="mt-1" />
                      <Label 
                        htmlFor="binding-paperback" 
                        className="flex flex-col cursor-pointer"
                      >
                        <span className="font-medium">Broché (Paperback)</span>
                        <span className="text-sm text-gray-500">Couverture souple</span>
                      </Label>
                    </div>
                    <div className="flex items-start space-x-2">
                      <RadioGroupItem value="hardcover" id="binding-hardcover" className="mt-1" />
                      <Label 
                        htmlFor="binding-hardcover" 
                        className="flex flex-col cursor-pointer"
                      >
                        <span className="font-medium">Relié (Hardcover)</span>
                        <span className="text-sm text-gray-500">Couverture rigide</span>
                      </Label>
                    </div>
                  </RadioGroup>
                </div>

                <div>
                  <h2 className="text-xl font-semibold mb-4">Plateforme cible</h2>
                  <Select value={platform} onValueChange={setPlatform}>
                    <SelectTrigger className="w-full md:w-1/2">
                      <SelectValue placeholder="Sélectionnez une plateforme" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="kdp">Amazon KDP</SelectItem>
                      <SelectItem value="ingramspark">IngramSpark</SelectItem>
                      <SelectItem value="lulu">Lulu</SelectItem>
                      <SelectItem value="blurb">Blurb</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </TabsContent>
              
              <TabsContent value="advanced" className="space-y-6 pt-6">
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-semibold">Formatage automatique</h2>
                    <Switch 
                      checked={autoFormat} 
                      onCheckedChange={setAutoFormat} 
                      id="auto-format"
                    />
                  </div>
                  <p className="text-gray-600 mb-4">
                    Lorsque cette option est activée, le système applique automatiquement les meilleures pratiques
                    de formatage selon la plateforme cible.
                  </p>
                </div>

                <div>
                  <h2 className="text-xl font-semibold mb-4">Marges</h2>
                  <div className="space-y-6">
                    <div>
                      <div className="flex justify-between mb-2">
                        <Label htmlFor="margin-slider">Taille des marges: {marginSize[0]} mm</Label>
                      </div>
                      <Slider
                        id="margin-slider"
                        min={10}
                        max={30}
                        step={1}
                        value={marginSize}
                        onValueChange={setMarginSize}
                        className="w-full"
                      />
                      <div className="flex justify-between text-xs text-gray-500 mt-1">
                        <span>Étroite</span>
                        <span>Standard</span>
                        <span>Large</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h2 className="text-xl font-semibold">Options supplémentaires</h2>
                  
                  <div className="flex items-center justify-between">
                    <Label htmlFor="page-numbers" className="cursor-pointer">
                      Numérotation des pages
                    </Label>
                    <Switch id="page-numbers" defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label htmlFor="chapter-breaks" className="cursor-pointer">
                      Sauts de page entre chapitres
                    </Label>
                    <Switch id="chapter-breaks" defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label htmlFor="table-contents" className="cursor-pointer">
                      Table des matières automatique
                    </Label>
                    <Switch id="table-contents" defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label htmlFor="hyphenation" className="cursor-pointer">
                      Césure automatique
                    </Label>
                    <Switch id="hyphenation" defaultChecked />
                  </div>
                </div>
              </TabsContent>
            </Tabs>

            <div className="flex justify-end space-x-4 pt-4 border-t">
              <Button variant="outline">
                Retour à l'import
              </Button>
              <Button 
                className="bg-teal-600 hover:bg-teal-700"
                onClick={handleFormatBook}
                disabled={isProcessing}
              >
                {isProcessing ? 'Formatage en cours...' : 'Formater le livre'}
              </Button>
            </div>
          </div>
        )}
      </div>
    </main>
  )
}
