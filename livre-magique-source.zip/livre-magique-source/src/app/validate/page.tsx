'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert'
import { Progress } from '@/components/ui/progress'
import { CheckCircle2, AlertTriangle, XCircle, Info } from 'lucide-react'

export default function ValidatePage() {
  const [isValidating, setIsValidating] = useState(false)
  const [validationComplete, setValidationComplete] = useState(false)
  const [validationProgress, setValidationProgress] = useState(0)
  const [validationResults, setValidationResults] = useState<any>(null)

  const handleStartValidation = async () => {
    setIsValidating(true)
    setValidationProgress(0)
    setValidationComplete(false)
    setValidationResults(null)
    
    // Simuler la progression de la validation
    const interval = setInterval(() => {
      setValidationProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval)
          return 100
        }
        return prev + 10
      })
    }, 300)
    
    // Simuler le temps de validation
    await new Promise(resolve => setTimeout(resolve, 3000))
    
    clearInterval(interval)
    setValidationProgress(100)
    
    // Résultats de validation simulés
    const results = {
      status: 'warning', // 'success', 'warning', 'error'
      summary: {
        passed: 8,
        warnings: 2,
        errors: 0
      },
      details: [
        {
          type: 'success',
          category: 'Format',
          message: 'Le format du livre est conforme aux exigences de KDP'
        },
        {
          type: 'success',
          category: 'Marges',
          message: 'Les marges sont correctement configurées'
        },
        {
          type: 'success',
          category: 'Pagination',
          message: 'La numérotation des pages est correcte'
        },
        {
          type: 'success',
          category: 'Polices',
          message: 'Les polices sont intégrées correctement'
        },
        {
          type: 'warning',
          category: 'Résolution d\'images',
          message: 'Certaines images ont une résolution inférieure à 300 DPI'
        },
        {
          type: 'warning',
          category: 'Table des matières',
          message: 'La table des matières pourrait être incomplète'
        },
        {
          type: 'success',
          category: 'Métadonnées',
          message: 'Les métadonnées du document sont complètes'
        },
        {
          type: 'success',
          category: 'Taille de fichier',
          message: 'La taille du fichier est dans les limites acceptables'
        },
        {
          type: 'success',
          category: 'Couverture',
          message: 'Les dimensions de la couverture sont correctes'
        },
        {
          type: 'success',
          category: 'Bleed',
          message: 'Les fonds perdus sont correctement configurés'
        }
      ]
    }
    
    setValidationResults(results)
    setIsValidating(false)
    setValidationComplete(true)
  }

  const getStatusIcon = (type: string) => {
    switch (type) {
      case 'success':
        return <CheckCircle2 className="h-5 w-5 text-green-500" />
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-amber-500" />
      case 'error':
        return <XCircle className="h-5 w-5 text-red-500" />
      default:
        return <Info className="h-5 w-5 text-blue-500" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success':
        return 'bg-green-50 border-green-200'
      case 'warning':
        return 'bg-amber-50 border-amber-200'
      case 'error':
        return 'bg-red-50 border-red-200'
      default:
        return 'bg-blue-50 border-blue-200'
    }
  }

  const getStatusTitle = (status: string) => {
    switch (status) {
      case 'success':
        return 'Validation réussie'
      case 'warning':
        return 'Validation avec avertissements'
      case 'error':
        return 'Validation échouée'
      default:
        return 'Validation terminée'
    }
  }

  return (
    <main className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-2">Validation des normes</h1>
        <p className="text-gray-600 mb-8">
          Vérifiez que votre livre est conforme aux exigences des plateformes d'impression.
        </p>

        {!validationComplete ? (
          <div className="space-y-6">
            <Card className="p-6">
              <h2 className="text-xl font-semibold mb-4">Validation de conformité</h2>
              <p className="text-gray-600 mb-6">
                Notre système va vérifier que votre livre respecte toutes les normes techniques requises par les plateformes d'impression à la demande comme Amazon KDP et IngramSpark.
              </p>

              {isValidating ? (
                <div className="space-y-4">
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium">Validation en cours...</span>
                    <span className="text-sm font-medium">{validationProgress}%</span>
                  </div>
                  <Progress value={validationProgress} className="h-2" />
                  <p className="text-sm text-gray-500 italic">
                    Veuillez patienter pendant que nous analysons votre livre...
                  </p>
                </div>
              ) : (
                <div>
                  <p className="mb-4">
                    La validation vérifiera les éléments suivants :
                  </p>
                  <ul className="list-disc list-inside space-y-1 text-gray-600 mb-6">
                    <li>Format et dimensions du livre</li>
                    <li>Marges et fonds perdus</li>
                    <li>Résolution des images</li>
                    <li>Polices intégrées</li>
                    <li>Pagination</li>
                    <li>Table des matières</li>
                    <li>Métadonnées</li>
                    <li>Couverture</li>
                  </ul>
                  <Button 
                    className="bg-teal-600 hover:bg-teal-700 w-full md:w-auto"
                    onClick={handleStartValidation}
                  >
                    Démarrer la validation
                  </Button>
                </div>
              )}
            </Card>
          </div>
        ) : (
          <div className="space-y-6">
            <Alert className={getStatusColor(validationResults.status)}>
              <AlertTitle className="flex items-center space-x-2">
                {getStatusIcon(validationResults.status)}
                <span>{getStatusTitle(validationResults.status)}</span>
              </AlertTitle>
              <AlertDescription>
                {validationResults.status === 'success' ? (
                  "Votre livre est conforme à toutes les exigences techniques. Vous pouvez procéder à l'exportation."
                ) : validationResults.status === 'warning' ? (
                  "Votre livre présente quelques avertissements, mais peut être exporté. Nous vous recommandons de corriger ces problèmes pour un résultat optimal."
                ) : (
                  "Votre livre présente des erreurs qui doivent être corrigées avant l'exportation."
                )}
              </AlertDescription>
            </Alert>

            <Card className="p-6">
              <h2 className="text-xl font-semibold mb-4">Résumé de la validation</h2>
              <div className="flex space-x-4 mb-6">
                <div className="flex-1 bg-green-50 rounded-lg p-4 text-center">
                  <span className="text-2xl font-bold text-green-600">{validationResults.summary.passed}</span>
                  <p className="text-green-700">Tests réussis</p>
                </div>
                <div className="flex-1 bg-amber-50 rounded-lg p-4 text-center">
                  <span className="text-2xl font-bold text-amber-600">{validationResults.summary.warnings}</span>
                  <p className="text-amber-700">Avertissements</p>
                </div>
                <div className="flex-1 bg-red-50 rounded-lg p-4 text-center">
                  <span className="text-2xl font-bold text-red-600">{validationResults.summary.errors}</span>
                  <p className="text-red-700">Erreurs</p>
                </div>
              </div>

              <h3 className="font-semibold mb-3">Détails de la validation</h3>
              <div className="space-y-3 mb-6">
                {validationResults.details.map((detail: any, index: number) => (
                  <div 
                    key={index} 
                    className={`p-3 rounded-lg flex items-start space-x-3 ${
                      detail.type === 'success' ? 'bg-green-50' : 
                      detail.type === 'warning' ? 'bg-amber-50' : 
                      'bg-red-50'
                    }`}
                  >
                    {getStatusIcon(detail.type)}
                    <div>
                      <p className="font-medium">{detail.category}</p>
                      <p className={`text-sm ${
                        detail.type === 'success' ? 'text-green-700' : 
                        detail.type === 'warning' ? 'text-amber-700' : 
                        'text-red-700'
                      }`}>
                        {detail.message}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex justify-between space-x-4">
                <Button 
                  variant="outline"
                  onClick={handleStartValidation}
                >
                  Relancer la validation
                </Button>
                <Button 
                  className="bg-teal-600 hover:bg-teal-700"
                  disabled={validationResults.status === 'error'}
                >
                  Passer à l'exportation
                </Button>
              </div>
            </Card>
          </div>
        )}
      </div>
    </main>
  )
}
