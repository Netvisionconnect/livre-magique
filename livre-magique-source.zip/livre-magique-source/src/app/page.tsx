'use client'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Upload, FileText, Settings, Eye, Download } from 'lucide-react'
import { useState } from 'react'
import Link from 'next/link'

export default function Home() {
  const [isHovered, setIsHovered] = useState<string | null>(null);

  const features = [
    {
      id: 'import',
      title: 'Import de manuscrit',
      description: 'Importez vos documents Word ou texte et conservez tous vos styles et mise en page.',
      icon: <Upload className="h-10 w-10 text-teal-500" />,
      href: '/import'
    },
    {
      id: 'format',
      title: 'Formatage automatique',
      description: 'Conversion automatique aux formats compatibles avec KDP et IngramSpark.',
      icon: <FileText className="h-10 w-10 text-teal-500" />,
      href: '/format'
    },
    {
      id: 'preview',
      title: 'Prévisualisation en temps réel',
      description: 'Visualisez votre livre comme il apparaîtra une fois imprimé.',
      icon: <Eye className="h-10 w-10 text-teal-500" />,
      href: '/preview'
    },
    {
      id: 'customize',
      title: 'Personnalisation avancée',
      description: 'Ajustez les marges, le formatage, et les styles selon vos préférences.',
      icon: <Settings className="h-10 w-10 text-teal-500" />,
      href: '/customize'
    },
    {
      id: 'export',
      title: 'Export multi-format',
      description: "Générez des fichiers PDF prêts pour l'impression et la distribution.",
      icon: <Download className="h-10 w-10 text-teal-500" />,
      href: '/export'
    }
  ];

  return (
    <main className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-900 to-teal-700 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Transformez votre manuscrit en livre professionnel</h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
            Créez des livres prêts à l'impression, conformes aux normes KDP et IngramSpark, sans compétence technique.
            La plateforme idéale pour les auteurs indépendants.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button size="lg" className="bg-teal-500 hover:bg-teal-600">
              Commencer gratuitement
            </Button>
            <Button size="lg" variant="outline" className="text-white border-white hover:bg-white/10">
              Découvrir les fonctionnalités
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">Tout ce qu'il faut pour créer votre livre</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature) => (
              <Link 
                href={feature.href} 
                key={feature.id}
                className="no-underline"
                onMouseEnter={() => setIsHovered(feature.id)}
                onMouseLeave={() => setIsHovered(null)}
              >
                <Card 
                  className={`p-6 h-full transition-all duration-200 ${
                    isHovered === feature.id ? 'shadow-lg transform -translate-y-1 border-teal-500' : ''
                  }`}
                >
                  <div className="flex flex-col h-full">
                    <div className="mb-4">{feature.icon}</div>
                    <h3 className="text-xl font-semibold mb-2 text-gray-800">{feature.title}</h3>
                    <p className="text-gray-600 flex-grow">{feature.description}</p>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-teal-50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6 text-gray-800">Prêt à transformer votre manuscrit?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto text-gray-600">
            Rejoignez des milliers d'auteurs qui ont déjà publié leurs livres avec notre plateforme.
          </p>
          <Button size="lg" className="bg-teal-600 hover:bg-teal-700">
            Commencer maintenant
          </Button>
        </div>
      </section>
    </main>
  )
}
