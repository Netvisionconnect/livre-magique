'use client'

import { useState } from 'react'
import { ColorPicker as ColorPickerComponent } from 'react-color'

interface ColorPickerProps {
  color: string
  onChange: (color: any) => void
}

export function ColorPicker({ color, onChange }: ColorPickerProps) {
  const [showPicker, setShowPicker] = useState(false)

  return (
    <div className="relative">
      <div 
        className="w-10 h-10 rounded border cursor-pointer"
        style={{ backgroundColor: color }}
        onClick={() => setShowPicker(!showPicker)}
      />
      
      {showPicker && (
        <div className="absolute z-10 mt-2">
          <div 
            className="fixed inset-0" 
            onClick={() => setShowPicker(false)}
          />
          <ColorPickerComponent 
            color={color}
            onChange={onChange}
          />
        </div>
      )}
    </div>
  )
}
