'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { useState } from 'react'
import { Menu, X } from 'lucide-react'

export function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  return (
    <nav className="bg-white border-b border-gray-200 py-4">
      <div className="container mx-auto px-4 flex justify-between items-center">
        {/* Logo */}
        <Link href="/" className="text-2xl font-bold text-teal-600 flex items-center">
          <span className="text-blue-900">Livre</span>Magique
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-8">
          <Link href="/features" className="text-gray-700 hover:text-teal-600 transition-colors">
            Fonctionnalités
          </Link>
          <Link href="/pricing" className="text-gray-700 hover:text-teal-600 transition-colors">
            Tarifs
          </Link>
          <Link href="/formats" className="text-gray-700 hover:text-teal-600 transition-colors">
            Formats
          </Link>
          <Link href="/help" className="text-gray-700 hover:text-teal-600 transition-colors">
            Aide
          </Link>
        </div>

        {/* Auth Buttons - Desktop */}
        <div className="hidden md:flex items-center space-x-4">
          <Button variant="outline" className="border-teal-600 text-teal-600 hover:bg-teal-50">
            Connexion
          </Button>
          <Button className="bg-teal-600 hover:bg-teal-700">
            S'inscrire
          </Button>
        </div>

        {/* Mobile Menu Button */}
        <button 
          className="md:hidden text-gray-700"
          onClick={toggleMenu}
          aria-label={isMenuOpen ? "Fermer le menu" : "Ouvrir le menu"}
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 py-4">
          <div className="container mx-auto px-4 flex flex-col space-y-4">
            <Link 
              href="/features" 
              className="text-gray-700 hover:text-teal-600 transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Fonctionnalités
            </Link>
            <Link 
              href="/pricing" 
              className="text-gray-700 hover:text-teal-600 transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Tarifs
            </Link>
            <Link 
              href="/formats" 
              className="text-gray-700 hover:text-teal-600 transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Formats
            </Link>
            <Link 
              href="/help" 
              className="text-gray-700 hover:text-teal-600 transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Aide
            </Link>
            <div className="flex flex-col space-y-2 pt-2 border-t border-gray-100">
              <Button variant="outline" className="border-teal-600 text-teal-600 hover:bg-teal-50 w-full">
                Connexion
              </Button>
              <Button className="bg-teal-600 hover:bg-teal-700 w-full">
                S'inscrire
              </Button>
            </div>
          </div>
        </div>
      )}
    </nav>
  )
}
